"""0xPdf API client."""

import json
from pathlib import Path
from typing import Any

import requests


class OxPDFError(Exception):
    """Raised when the 0xPdf API returns an error."""

    def __init__(self, message: str, status_code: int | None = None, response_body: str | None = None):
        super().__init__(message)
        self.status_code = status_code
        self.response_body = response_body


class Client:
    """Sync client for the 0xPdf PDF-to-JSON API."""

    def __init__(self, api_key: str, base_url: str = "https://api.0xpdf.com/api/v1"):
        self.api_key = api_key
        self.base_url = base_url.rstrip("/")
        self._session = requests.Session()
        self._session.headers["X-API-Key"] = api_key

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: dict[str, Any] | None = None,
        files: dict[str, tuple[str, bytes | None, str]] | None = None,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        url = f"{self.base_url}/{path.lstrip('/')}"
        try:
            resp = self._session.request(
                method,
                url,
                params=params,
                files=files,
                data=data,
                timeout=120,
            )
        except requests.RequestException as e:
            raise OxPDFError(str(e)) from e

        if not resp.ok:
            try:
                body = resp.json()
                detail = body.get("detail", body.get("error", resp.text))
                if isinstance(detail, list):
                    detail = "; ".join(str(d.get("msg", d)) for d in detail)
                elif not isinstance(detail, str):
                    detail = str(detail)
            except Exception:
                detail = resp.text or resp.reason or f"HTTP {resp.status_code}"
            raise OxPDFError(
                detail,
                status_code=resp.status_code,
                response_body=resp.text,
            )

        if not resp.content:
            return {}
        return resp.json()

    def parse(
        self,
        file_path: str,
        *,
        schema: dict[str, Any] | None = None,
        schema_template: str | None = None,
        schema_id: str | None = None,
        use_ocr: bool = False,
        pages: list[int] | None = None,
    ) -> dict[str, Any]:
        """Parse a PDF file and return structured JSON data."""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {file_path}")
        if not path.suffix.lower() == ".pdf":
            raise ValueError("File must be a PDF")

        params: dict[str, Any] = {}
        if schema_id:
            params["schema_id"] = schema_id
        if schema_template:
            params["schema_template"] = schema_template
        if pages:
            params["pages"] = ",".join(str(p) for p in pages)

        data: dict[str, Any] = {"use_ocr": use_ocr}
        if schema is not None:
            data["schema_json"] = json.dumps(schema)

        with path.open("rb") as f:
            files = {"file": (path.name, f.read(), "application/pdf")}

        return self._request(
            "POST",
            "pdf/parse",
            params=params or None,
            files=files,
            data=data,
        )

    def list_templates(self) -> list[dict[str, Any]]:
        """List available schema templates."""
        out = self._request("GET", "pdf/templates")
        return out.get("templates", [])

    def list_schemas(self) -> list[dict[str, Any]]:
        """List user's saved schemas."""
        out = self._request("GET", "schemas")
        return out.get("schemas", [])
