# oxpdf

Python SDK for the [0xPdf](https://0xpdf.com) PDF-to-JSON API.

## Installation

```bash
pip install oxpdf
```

## Quick Start

```python
from oxpdf import Client

client = Client(api_key="your_api_key")

# Parse with a built-in template
result = client.parse("invoice.pdf", schema_template="invoice")
print(result["data"])

# Parse with a custom schema
result = client.parse("doc.pdf", schema={
    "type": "object",
    "properties": {
        "title": {"type": "string"},
        "amount": {"type": "number"}
    }
})

# List available templates
templates = client.list_templates()
```

## Error Handling

```python
from oxpdf import Client, OxPDFError

client = Client(api_key="your_api_key")

try:
    result = client.parse("doc.pdf", schema_template="invoice")
except OxPDFError as e:
    print(f"API error: {e} (status: {e.status_code})")
except FileNotFoundError:
    print("PDF file not found")
```

## API Reference

### `Client(api_key, base_url="https://api.0xpdf.com/api/v1")`

### `client.parse(file_path, *, schema=None, schema_template=None, schema_id=None, use_ocr=False, pages=None)`

### `client.list_templates()`

### `client.list_schemas()`
